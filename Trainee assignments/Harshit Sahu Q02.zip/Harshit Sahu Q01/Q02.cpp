int TS_GO = 0;
int schmittTrigger = 0;

void hv_resert()
{
    digitalWrite(10, HIGH);
    digitalWrite(13, LOW);
}

void setup()
{
    pinMode(4, INPUT);
    pinMode(A0, INPUT);
    pinMode(A1, INPUT);
    pinMode(2, INPUT);
    pinMode(6, INPUT);
    pinMode(7, INPUT);
    pinMode(13, OUTPUT);
    pinMode(12, OUTPUT);
    pinMode(10, OUTPUT);
    attachInterrupt(digitalPinToInterrupt(2), hv_reset, FALLING);
    Serial.begin(9600);
}

void loop()
{

    int error1 = digitalRead(6);
    int error2 = digitalRead(7);

    if (error1 == 0 || error2 == 0)
    {
        digitalWrite(13, HIGH);
        digitalWrite(12, HIGH);
        digitalWrite(10, LOW);
    }

    if (analogRead(A0) > 1023 * 2 / 3 && digitalRead(4) == 1)
    {
        TS_GO = 1;
    }

    if (analogRead(2) == 1)
    {
        TS_GO = 1;
    }
    if (analogRead(A1) < 0.95 * analogRead(A0) && analogRead(A1) > 0.75 * analogRead(A0))
    {
        schmittTrigger = 1;
    }
    if (schmittTrigger && TS_GO)
    {
        digitalWrite(13, LOW);
        digitalWrite(12, LOW);
    }
    Serial.print("Relay: ");
    Serial.print(digitalRead(10) ? "ON" : "OFF");
    Serial.print(", Negative Contactor: ");
    Serial.print(!digitalRead(12) ? "CLOSED" : "OPEN");
    Serial.print(", Positive Contactor: ");
    Serial.println(!digitalRead(13) ? "CLOSED" : "OPEN");
    delay(50);
}